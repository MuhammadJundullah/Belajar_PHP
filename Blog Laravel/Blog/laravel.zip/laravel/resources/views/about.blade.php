<x-layout>   
    <x-slot:title>{{$title}}</x-slot:title>
    <h3>Selamat datang di {{$title}}</h3>
    <p>Nama : {{$nama}}</p>
</x-layout>

