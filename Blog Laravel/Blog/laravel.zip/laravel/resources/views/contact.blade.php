<x-layout>
  <x-slot:title>{{$title}}</x-slot:title>
  <h3>Selamat datang di Contact !</h3>
</x-layout>